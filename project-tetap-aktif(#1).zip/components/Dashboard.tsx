"use client";

import React, { useState } from 'react';
import { UserProfile } from '@/lib/types';
import { Exercise, getRecommendedExercises } from '@/lib/data';
import { PlayCircle, Bell, BellRing, Settings, Edit3 } from 'lucide-react';
import { motion } from 'motion/react';

interface DashboardProps {
  profile: UserProfile;
  onStartWorkout: (exercises: Exercise[]) => void;
  onEditProfile: () => void;
}

export default function Dashboard({ profile, onStartWorkout, onEditProfile }: DashboardProps) {
  const [remindersEnabled, setRemindersEnabled] = useState(false);

  const recommendedExercises = getRecommendedExercises(
    profile.limitations || ((profile as any).limitation ? [(profile as any).limitation] : []), 
    profile.medicalConditions || ((profile as any).medicalCondition ? [(profile as any).medicalCondition] : [])
  );

  const toggleReminders = () => {
    setRemindersEnabled(!remindersEnabled);
  };

  const getLimitationTexts = () => {
    const lims = profile.limitations || ((profile as any).limitation ? [(profile as any).limitation] : []);
    if (!lims || lims.length === 0 || lims.includes('tidak_ada')) return [];
    return lims.map(l => l === 'nyeri_lutut' ? 'Nyeri Lutut' : 'Nyeri Punggung');
  };

  const getConditionTexts = () => {
    const conds = profile.medicalConditions || ((profile as any).medicalCondition ? [(profile as any).medicalCondition] : []);
    if (!conds || conds.length === 0 || conds.includes('tidak_ada')) return [];
    return conds.map(c => c === 'hipertensi' ? 'Hipertensi' : c === 'artritis' ? 'Artritis' : 'Osteoporosis');
  };

  const limitationTexts = getLimitationTexts();
  const conditionTexts = getConditionTexts();
  const isHealthy = limitationTexts.length === 0 && conditionTexts.length === 0;

  return (
    <div className="max-w-6xl mx-auto p-4 md:px-8 md:py-6 lg:h-[100dvh] flex flex-col overflow-hidden">
      
      {/* Header */}
      <header className="flex flex-col md:flex-row md:items-center justify-between pb-6 mb-6 border-b border-brand-brown/10 gap-6 shrink-0">
        <div className="flex flex-col">
          <span className="text-xs md:text-sm tracking-[0.2em] uppercase opacity-60 font-semibold mb-1">Pendamping Kesehatan Lansia</span>
          <h1 className="editorial-title text-4xl md:text-5xl">Tetap Aktif</h1>
        </div>
        
        <div className="flex items-center gap-4 md:gap-6">
          <div className="text-right hidden md:block">
            <p className="text-sm opacity-60">Selamat Datang,</p>
            <p className="text-xl font-bold">Usia {profile.ageRange}</p>
          </div>
          <div className="flex items-center gap-3">
            <button 
              onClick={onEditProfile}
              className="w-14 h-14 rounded-full flex items-center justify-center transition-all shrink-0 glass-card text-gray-500 hover:text-brand-terracotta"
              title="Ubah Profil"
            >
              <Edit3 className="w-6 h-6" />
            </button>
            <button 
              onClick={toggleReminders} 
              className={`w-14 h-14 rounded-full flex items-center justify-center transition-all shrink-0 ${
                remindersEnabled 
                  ? 'glass-card text-brand-terracotta border-brand-terracotta' 
                  : 'glass-card text-gray-500 hover:text-brand-terracotta'
              }`}
              title="Pengingat Latihan"
            >
              {remindersEnabled ? <BellRing className="w-6 h-6" /> : <Bell className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </header>

      <div className="flex flex-col lg:flex-row gap-8 flex-1 min-h-0">
        {/* Left Column: Profile */}
        <section className="w-full lg:w-[350px] flex flex-col gap-6 shrink-0">
          <div className="glass-card p-6 rounded-3xl relative flex-shrink-0">
            <p className="text-sm uppercase tracking-widest opacity-60 mb-4 pr-10">Profil Kesehatan Anda</p>
            <div className="flex flex-wrap gap-2">
              {limitationTexts.map(text => (
                <span key={text} className="bg-white px-4 py-2 rounded-full border border-brand-terracotta/30 text-sm font-semibold text-brand-brown">
                  {text}
                </span>
              ))}
              {conditionTexts.map(text => (
                <span key={text} className="bg-white px-4 py-2 rounded-full border border-brand-terracotta/30 text-sm font-semibold text-brand-brown">
                  {text}
                </span>
              ))}
              {isHealthy && (
                <span className="bg-white px-4 py-2 rounded-full border border-brand-terracotta/30 text-sm font-semibold text-brand-brown">
                  Kondisi Sehat
                </span>
              )}
            </div>
          </div>
        </section>

        {/* Right Column: Workouts */}
        <section className="flex-1 w-full flex flex-col gap-4 min-h-0">
          <div className="flex items-center justify-between shrink-0">
            <h2 className="text-2xl md:text-3xl font-bold editorial-title">Rekomendasi Latihan Hari Ini</h2>
          </div>
          
          {recommendedExercises.length === 0 ? (
            <div className="p-8 glass-card rounded-3xl text-center shrink-0">
              <p className="text-xl opacity-60">Belum ada latihan yang cocok. Mohon hubungi dokter untuk saran latihan fisik.</p>
            </div>
          ) : (
            <div className="flex flex-col gap-6 flex-1 min-h-0">
              <div className="glass-card rounded-3xl p-4 md:p-6 overflow-y-auto min-h-0">
                <div className="divide-y divide-brand-brown/10">
                  {recommendedExercises.map((ex, index) => (
                    <div key={ex.id} className="py-4 first:pt-0 last:pb-0 flex items-center justify-between transition-colors">
                      <div className="flex items-center space-x-4 md:space-x-6">
                        <div className="w-12 h-12 rounded-full border-2 border-brand-terracotta/30 flex items-center justify-center font-bold text-xl text-brand-terracotta shrink-0">
                          {index + 1}
                        </div>
                        <div>
                          <h3 className="text-xl md:text-2xl font-bold text-brand-brown">{ex.name}</h3>
                          <p className="text-sm opacity-60">{ex.defaultSets} Set &times; {ex.defaultReps} Repetisi</p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <button
                onClick={() => onStartWorkout(recommendedExercises)}
                className="w-full bg-brand-terracotta text-white py-5 md:py-6 rounded-2xl text-xl md:text-2xl font-bold shadow-lg shadow-brand-terracotta/20 flex items-center justify-center hover:bg-brand-terracotta-dark transition-colors shrink-0"
              >
                <PlayCircle className="w-8 h-8 mr-4" />
                Mulai Latihan Sekarang
              </button>
            </div>
          )}
        </section>
      </div>

    </div>
  );
}
